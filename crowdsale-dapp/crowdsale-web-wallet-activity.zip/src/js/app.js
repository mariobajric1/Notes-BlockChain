$checkBalanceAddress_INPUT = $('#checkBalanceAddress');
$balanceOfAddressProvided_SPAN = $('#balanceOfAddressProvided');
$crowdSaleTokensAvailable_SPAN = $('#crowdSaleTokensAvailable');
$dateStartOfCrowdSale_SPAN = $('#dateStartOfCrowdSale');
$addressWhereFundsGoto_SPAN = $('#addressWhereFundsGoto');
$etherRaised_SPAN = $('#etherRaised');
$tokensSold_SPAN = $('#tokensSold');
$rate_SPAN = $('#rate');

App = {
    web3Provider: null,
    contracts: {},

    init: function() {
        return App.initWeb3();
    },

    initWeb3: function() {
        // Initialize web3 and set the provider to the testRPC.
        if (typeof web3 !== 'undefined') {
            App.web3Provider = web3.currentProvider;
            web3 = new Web3(web3.currentProvider);
        } else {
            // set the provider you want from Web3.providers
            App.web3Provider = new Web3.providers.HttpProvider('http://127.0.0.1:7545');
            web3 = new Web3(App.web3Provider);
        }

        return App.initContract();
    },

    initContract: function() {
        $.getJSON('TutorialToken.json', function(data) {
            // Get the necessary contract artifact file and instantiate it with truffle-contract.
            var TutorialTokenArtifact = data;
            App.contracts.TutorialToken = TruffleContract(TutorialTokenArtifact);

            // Set the provider for our contract.
            App.contracts.TutorialToken.setProvider(App.web3Provider);

            $.getJSON('Sale.json', function(data) {
                // Get the necessary contract artifact file and instantiate it with truffle-contract.
                var SaleArtifact = data;
                App.contracts.Sale = TruffleContract(SaleArtifact);

                // Set the provider for our contract.
                App.contracts.Sale.setProvider(App.web3Provider);

                //get the balance of erc20 tokens the current user has and put that on the page
                return App.getBalances();
            });
        });

        return App.bindEvents();
    },

    bindEvents: function() {
        $(document).on('click', '#transferButton', App.handleTransfer);
        $(document).on('click', '#checkBalanceButton', App.checkBalanceOfAddressProvided);
        $(document).on('click', '#purchaseTcT', App.purchaseTct);
    },
    getBalances: function() {
        console.log('Getting balances...');

        var tutorialTokenInstance;

        web3.eth.getAccounts(function(error, accounts) {
            if (error) {
                console.log(error);
            }

            var account = accounts[0];

            App.contracts.TutorialToken.deployed().then(function(instance) {
                tutorialTokenInstance = instance;

                return tutorialTokenInstance.balanceOf(account);
            }).then(function(result) {
                balance = result.toNumber();

                $('#TTBalance').text(balance);

                return App.getCrowdSaleDetails();
            }).catch(function(err) {
                console.log(err.message);
            });
        });
    },
    getCrowdSaleDetails: function() {

        var tutorialTokenInstance;
        var saleInstance;

        App.contracts.TutorialToken.deployed().then(function(instance) {
            tutorialTokenInstance = instance;

            App.contracts.Sale.deployed().then(function(instance) {
                saleInstance = instance;

                var promises = [];

                //the first element pushed into promises
                    //is the address of the Sale contract to the balanceOf function in the TutorialToken contract
                promises.push(tutorialTokenInstance.balanceOf(saleInstance.address), saleInstance.deployed_time(), saleInstance.wallet(), saleInstance.rate(), saleInstance.weiRaised(), saleInstance.tokens_sold());

                return Promise.all(promises);

            }).then(function(result){

                var balance = result[0].toNumber();

                var dateStartOfCrowdSale = new Date(result[1].toNumber()*1000);

                var addressWhereFundsGoto = result[2];

                var rate = web3.fromWei(result[3].toNumber());

                var etherRaised = web3.fromWei(result[4].toNumber());

                var tokensSold =  result[5].toNumber();

                $crowdSaleTokensAvailable_SPAN.text(balance);

                $dateStartOfCrowdSale_SPAN.text(dateStartOfCrowdSale);

                $addressWhereFundsGoto_SPAN.text(addressWhereFundsGoto);

                $rate_SPAN.text(rate);
                
                $etherRaised_SPAN.text(etherRaised);

                $tokensSold_SPAN.text(tokensSold);

            }).catch(function(err) {
                console.log(err.message);
            });
        }).catch(function(err) {
            console.log(err.message);
        });

    },
    handleTransfer: function(event) {
        event.preventDefault();

        var amount = parseInt($('#TTTransferAmount').val());
        var toAddress = $('#TTTransferAddress').val();

        console.log('Transfer ' + amount + ' TT to ' + toAddress);

        var tutorialTokenInstance;

        web3.eth.getAccounts(function(error, accounts) {
            if (error) {
                console.log(error);
            }

            var account = accounts[0];

            App.contracts.TutorialToken.deployed().then(function(instance) {
                tutorialTokenInstance = instance;

                return tutorialTokenInstance.transfer(toAddress, amount, { from: account });
            }).then(function(result) {
                alert('Transfer Successful!');
                return App.getBalances();
            }).catch(function(err) {
                console.log(err.message);
            });
        });
    },
    checkBalanceOfAddressProvided: function(event) {
        event.preventDefault();

        var tutorialTokenInstance;

        web3.eth.getAccounts(function(error, accounts) {
            if (error) {
                console.log(error);
            }

            App.contracts.TutorialToken.deployed().then(function(instance) {
                tutorialTokenInstance = instance;

                return tutorialTokenInstance.balanceOf($checkBalanceAddress_INPUT.val());
            }).then(function(result) {
                var balance = result.toNumber();

                $balanceOfAddressProvided_SPAN.text(balance);
            }).catch(function(err) {
                console.log(err.message);
            });
        });
    },
    purchaseTct: function(event) {
        event.preventDefault();

        alert('write code here');
    }

};

$(function() {
    $(window).load(function() {
        App.init();
    });
});